﻿//=============================================================================
// Specify common usings here, so don't have to put in each script.
// The utility script Assembly is included in each query script project
// and each mod project.  This utility (Global) script is also included in
// each query script project and each mod project.
//=============================================================================

global using global::System;
global using global::System.Collections;
global using global::System.Collections.Generic;
global using global::System.Diagnostics;
global using global::System.IO;
global using global::System.Reflection;
global using global::System.Text;
global using global::System.Text.RegularExpressions;
global using global::System.Threading;
global using global::System.Threading.Tasks;

global using global::ClosedXML;

global using global::libMBIN.NMS.Globals;
global using global::libMBIN.NMS.GameComponents;
global using global::libMBIN.NMS.Toolkit;
global using global::libMBIN.NMS.SketchNodes;

global using global::cmk;
global using global::cmk.NMS;  // required for some extension methods

global using nms = global::libMBIN.NMS;
global using NMS = global::cmk.NMS;

global using LanguageId = global::cmk.NMS.Game.Language.Identifier;
global using Excel      = global::ClosedXML.Excel;

//=============================================================================
