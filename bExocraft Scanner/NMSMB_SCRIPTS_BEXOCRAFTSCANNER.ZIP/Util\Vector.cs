﻿//=============================================================================

public static partial class _x_
{
	public static nms.Vector2f Scale(
		this nms.Vector2f LHS, double SCALE
	) => new(
		(float)(LHS.X * SCALE),
		(float)(LHS.Y * SCALE)
	);

	//...........................................................

	public static nms.Vector3f Scale(
		this nms.Vector3f LHS, double SCALE
	) => new(
		(float)(LHS.X * SCALE),
		(float)(LHS.Y * SCALE),
		(float)(LHS.Z * SCALE)
	);

	//...........................................................

	public static nms.Vector4f Scale(
		this nms.Vector4f LHS, double SCALE
	) => new(
		(float)(LHS.X * SCALE),
		(float)(LHS.Y * SCALE),
		(float)(LHS.Z * SCALE),
		(float)(LHS.W * SCALE)
	);
}

//=============================================================================
